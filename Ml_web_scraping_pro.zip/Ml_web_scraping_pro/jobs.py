import pandas as pd
import requests
from bs4 import BeautifulSoup

headers = {
    'User-Agent': 'Mozilla/5.0'
}

url = "https://www.ambitionbox.com/list-of-companies"
res = requests.get(url, headers=headers)
soup = BeautifulSoup(res.text, "html.parser")

companies = soup.find_all("div", class_="companyCardWrapper")

company_list = []

for c in companies:
    name = c.find("h2").text.strip() if c.find("h2") else "N/A"
    rating = c.find("span", class_="companyCardWrapper__companyRatingValue").text.strip() if c.find("span", class_="companyCardWrapper__companyRatingValue") else "N/A"
    reviews = c.find("span", class_="companyCardWrapper__ActionCount").text.strip() if c.find("span", class_="companyCardWrapper__ActionCount") else "N/A"
    location = c.find("span", class_="companyCardWrapper__interLinking").text.strip() if c.find("span", class_="companyCardWrapper__interLinking") else "N/A"

    company_list.append({
        "Company": name,
        "Rating": rating,
        "Reviews": reviews,
        "Location": location
    })

df = pd.DataFrame(company_list)
df.to_csv("ambitionbox_companies.csv", index=False)

print(df.head())
